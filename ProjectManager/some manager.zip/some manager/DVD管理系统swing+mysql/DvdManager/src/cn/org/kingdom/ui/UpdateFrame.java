package cn.org.kingdom.ui;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import cn.org.kingdom.entity.Dvd;
import cn.org.kingdom.util.JdbcUtil;

public class UpdateFrame extends JFrame {
	public UpdateFrame(final Dvd dvd,final JTable jt){
		this.setTitle("�޸�dvd����Ϣ");
		this.setSize(300,300);
		this.setLayout(new GridLayout(5, 2));
		
		JLabel jlb1 =new JLabel("����");
		final JTextField jtf1 = new JTextField();
		jtf1.setText(dvd.getDname());
		JLabel jlb2 =new JLabel("�������");
		
		final JTextField jtf2= new JTextField();
		
		
		jtf2.setText(dvd.getCount()+"");
		JLabel jlb3 =new JLabel("״̬");
		final JTextField jtf3 = new JTextField();
		
		
		jtf3.setText(dvd.getStatus()+"");
		JLabel jlb4 =new JLabel("����");
		final JTextField jtf4 = new JTextField();
		jtf4.setText(dvd.getLend_date());
		
		JButton jbtn = new JButton("�޸�");
		
		
		jbtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				int did = dvd.getDid();
				String name = jtf1.getText();
				int count = Integer.valueOf(jtf2.getText());
				int status = Integer.valueOf(jtf3.getText()) ;
				String date = jtf4.getText();
				int res = JdbcUtil.executeUpdate("update t_dvd set dname=?,count=?,status=?,lend_date=? where did=?", new Object[]{name,count,status,date,did});
				if(res>0) {
					JOptionPane.showMessageDialog(UpdateFrame.this, "�޸ĳɹ�");
					jt.setModel(new DvdTableModel());
					UpdateFrame.this.dispose();
				}
			}
		});
		
		this.add(jlb1);
		this.add(jtf1);
		
		this.add(jlb2);
		this.add(jtf2);
		this.add(jlb3);
		this.add(jtf3);
		this.add(jlb4);
		this.add(jtf4);
		
		this.add(jbtn);
		this.setVisible(true);
	}
}
