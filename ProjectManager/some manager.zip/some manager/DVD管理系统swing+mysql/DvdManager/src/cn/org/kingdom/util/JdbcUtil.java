package cn.org.kingdom.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JdbcUtil {
	private static final String DB_DRIVER = "org.gjt.mm.mysql.Driver" ; 
	private static final String DB_URL = "jdbc:mysql://localhost:3306/mytest?Unicode=true;characterEncoding=utf8" ; 
	private static final String DB_USER = "root" ; 
	private static final String DB_PWD = "root" ;
	
	public static Connection conn ; 
	
	
	public static PreparedStatement pstmt ; 
	
	
	public static ResultSet rs ; 
	
	
	static{
		try {
			Class.forName(DB_DRIVER);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//��ȡ���ӵĲ���
	public static  void setConnection(){
		try {
			conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PWD);
			System.out.println(conn);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		JdbcUtil.setConnection();
	}
	
	public static int executeUpdate(String sql,Object[] params) {
		int result = -1 ;
		setConnection();
		try {
			pstmt = conn.prepareStatement(sql) ;
			if(params!=null) {
				for (int i = 0; i < params.length; i++) {
					pstmt.setObject(i+1, params[i]);
				}
			}
			result= pstmt.executeUpdate() ; 
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			//�ر���Դ�Ĳ���
			close();
		}
		return result ; 
	}
	
	
	public static void executeQuery(String sql,Object[] params) {
		setConnection();
		try {
			pstmt = conn.prepareStatement(sql) ;
			if(params!=null) {
				for (int i = 0; i < params.length; i++) {
					pstmt.setObject(i+1, params[i]);
				}
			}
			rs = pstmt.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	
	public static void close(){
		if(rs!=null) {
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(pstmt!=null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(conn!=null) {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	
	
	
	
	
}
