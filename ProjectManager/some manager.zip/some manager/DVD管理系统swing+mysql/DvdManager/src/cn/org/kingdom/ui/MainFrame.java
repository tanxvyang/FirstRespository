package cn.org.kingdom.ui;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;

import cn.org.kingdom.entity.Dvd;
import cn.org.kingdom.util.JdbcUtil;
@SuppressWarnings("all")
public class MainFrame extends JFrame {
	JTable jt  ; 
	public MainFrame(){
		this.setTitle("dvd����");
		//����������Ĵ�С
		this.setSize(500, 500);
		JMenuBar jmb  = new JMenuBar();
		this.add(jmb,BorderLayout.NORTH);
		JMenu jm = new JMenu("ϵͳ");
		jmb.add(jm);
		JMenuItem jmi1 = new JMenuItem("�˳�");
		jmi1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(-1);
			}
		});
		JMenuItem jmi2 = new JMenuItem("�������ǣ�");
		jmi2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new LinkFrame();
			}
		});
		jm.add(jmi1);
		jm.add(jmi2);
		
		
		
		JMenu jm2 = new JMenu("DVD����");
		
		
		JMenuItem jmi_add = new JMenuItem("����dvd");
		JMenuItem jmi_update = new JMenuItem("�޸�dvd");
		//Ϊ�޸������¼�
		
		jmi_update.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				int selectIndex = jt.getSelectedRow();
				if(selectIndex==-1) {
					JOptionPane.showMessageDialog(MainFrame.this, "��ѡ��Ҫ�޸ĵ���");
					return ;
				}
				Dvd dvd = new Dvd();
				dvd.setDid(Integer.valueOf(jt.getValueAt(selectIndex, 0).toString()));
				dvd.setDname(jt.getValueAt(selectIndex, 1).toString());
				dvd.setCount(Integer.valueOf(jt.getValueAt(selectIndex, 2).toString()));
				dvd.setStatus(Integer.valueOf(jt.getValueAt(selectIndex, 3).toString()));
				dvd.setLend_date(jt.getValueAt(selectIndex, 4).toString());
				
				
				new UpdateFrame(dvd,jt);
				
			}
		});
		
		
		JMenuItem jmi_delete = new JMenuItem("ɾ��dvd");
		
		//��ɾ������������
		jmi_delete.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int selectIndex = jt.getSelectedRow();
				if(selectIndex==-1) {
					JOptionPane.showMessageDialog(MainFrame.this, "��ѡ��Ҫɾ������");
					return ;
				}
				int result = JOptionPane.showConfirmDialog(MainFrame.this, "ȷ��ɾ����","����",JOptionPane.OK_CANCEL_OPTION,JOptionPane.ERROR_MESSAGE);
				if(result==JOptionPane.OK_OPTION) {
					int did = Integer.valueOf(jt.getValueAt(selectIndex, 0).toString());
					int res= JdbcUtil.executeUpdate("delete from t_dvd where did=?", new Object[]{did});
					if(res>0) {
						JOptionPane.showMessageDialog(MainFrame.this, "ɾ���ɹ�");
						jt.setModel(new DvdTableModel());
						
					}
				}
			}
		});
		jm2.add(jmi_add);
		jm2.add(new JSeparator());
		jm2.add(jmi_update);
		
		jm2.add(jmi_delete);
		jm2.add(new JSeparator());
		jmb.add(jm2);
		
		
		
		
		//�м䲿�ֵ����
		
		JPanel jp = new JPanel()  ; 
		
		
		this.add(jp,BorderLayout.CENTER);
		
		
		//Jtable��ʾ����
		
		
		
		
		
		jt = new JTable(new DvdTableModel());
		
		JScrollPane jsp = new JScrollPane(jt);
		
		
		jp.add(jsp,BorderLayout.CENTER);
		
		
		
		
		
		
		
		
		
		
		
		this.setVisible(true);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	public static void main(String[] args) {
		new MainFrame();
	}
}
