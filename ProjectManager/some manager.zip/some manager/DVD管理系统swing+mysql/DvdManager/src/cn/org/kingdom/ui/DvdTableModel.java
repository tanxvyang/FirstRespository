package cn.org.kingdom.ui;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import cn.org.kingdom.entity.Dvd;
import cn.org.kingdom.util.JdbcUtil;

public class DvdTableModel extends AbstractTableModel {
	
	private String columns[] ={"���","����","�������","״̬","����"};
	
	private Object[][] datas = new Object[0][0];
	
	
	public DvdTableModel(){
		JdbcUtil.executeQuery("SELECT t_dvd.did,t_dvd.dname,t_dvd.count,t_dvd.`status`,t_dvd.lend_date FROM t_dvd", null);
		List<Dvd> list =new ArrayList<Dvd>();
		try {
			while(JdbcUtil.rs.next()) {
				Dvd dvd = new Dvd();
				dvd.setDid(JdbcUtil.rs.getInt(1));
				dvd.setDname(JdbcUtil.rs.getString(2));
				dvd.setCount(JdbcUtil.rs.getInt(3));
				dvd.setStatus(JdbcUtil.rs.getInt(4));
				dvd.setLend_date(JdbcUtil.rs.getDate(5).toString());
				list.add(dvd);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			JdbcUtil.close();
		}
		
		
		if(list!=null&&list.size()>0) {
			datas = new Object[list.size()][columns.length] ; 
			Iterator<Dvd> iter = list.iterator();
			int i = 0 ; 
			while(iter.hasNext()) {
				Dvd d = iter.next() ; 
				datas[i][0] = d.getDid()+"";
				datas[i][1] = d.getDname();
				datas[i][2] = d.getCount()+"" ;  
				datas[i][3] = d.getStatus()+"" ; 
				datas[i][4] = d.getLend_date();
				i++ ; 
			}
		}
		
	}
	
	
	
	
	@Override
	public String getColumnName(int column) {
		return columns[column];
	}




	//�����е�����
	public int getRowCount() {
		
		return datas.length;
	}

	//�����е�����
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return columns.length;
	}
	//����ĳ��ĳ�е�alue
	public Object getValueAt(int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		return datas[rowIndex][columnIndex];
	}

}
