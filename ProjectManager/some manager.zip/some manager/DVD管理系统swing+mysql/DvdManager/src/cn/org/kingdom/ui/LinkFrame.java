package cn.org.kingdom.ui;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class LinkFrame extends JFrame {
	
	
	
	public LinkFrame(){
		this.setTitle("����ϵqq:183588002");
		this.setSize(300, 300);
		Icon icon = new ImageIcon("src/test.png");
		JLabel jlb = new JLabel(icon);
		this.add(jlb);
		this.setVisible(true);
		
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
}
