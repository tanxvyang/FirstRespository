package hotel;

public class Coustomer {
    private String name;

    public Coustomer(String name) {  //构造方法
        this.name = name;
    }

    public String getName() {   //获得姓名
        return name;
    }
    public String toString(){
        return name;
    }




}
