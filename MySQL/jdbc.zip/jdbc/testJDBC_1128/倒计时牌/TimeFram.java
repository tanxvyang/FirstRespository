package jdbc.testJDBC_1128.倒计时牌;

import javax.swing.*;

public class TimeFram {
    private JFrame jf;
    private JLabel jl1;
    private JLabel jl2;
    private String title;

    public TimeFram(String title){
        this.title=title;
        jf=new JFrame(title+"倒计时牌");
        jl1=new JLabel("距离"+"");
    }
}
